# HtgEMWqrPQyfJXVObdJvlRt2

## Design

1. Build application in docker by node js. URL shortening with base64 in 9 character length.
5. Terraform script to create an elastic beanstalk application. Which has a load balancer. Easy deploy web application. Can easy autoscaling up. DNS provided for public access.

## Actual Done

- Create an app contains only a endpoint `/` to return HTTP 200 only in Node JS.
- Write some terraform script
- Not doing any test yet.


## Assumption

### Local

1. `awscli` command is install by `pip install awscli`.

### AWS

1. A usable assume role should be created for this terraform scripts to be executed.
2. Security group ingress CIDR block should be set to use office network only.

### Terraform

1. `terraform` is already installed.
1. IAM role is already created to execute the script.

## Limitation

### Infra Design
1. Different environments required for the application.
2. Hardware level Monitoring for the EC2 instances should be implemented
3. Health check for the EC2 only for the autoscaling group. Not overwhelming the requests for each application in each EC2.
4. Network Connectivity monitoring between load balancer and autoscaling group should be implemented.
4. Alerts send to slack (AWS SNS) should be implemented
4. Alerts should be sent when there are no more requests can be handled.
4. (Terraform) Save remote state in the s3 bucket.
4. No Autoscaling down EC2 design. Wasting resources.
4. No way to upload source file


### Application Design
1. Use base64 hash to hash the URL. No security at all.
2. Unit test should be implemented
3. Dockerize the application would be better to ensure same binaries, config are deployed into the EC2.
4. EFK should be implemented for the application to be read in the log.
5. Logging for each requests should be proper monitored.
6. No HTTPS is implemented. May have security issue.

### Code Level
1. Infra and application code should be in a separated Git repository.

## Notes

More monitoring should be implemented when the system goes live.

# Simple Rest API

Retry HTTP 200 from `/`

# Installation

```bash
    npm install
    npm run start &
```

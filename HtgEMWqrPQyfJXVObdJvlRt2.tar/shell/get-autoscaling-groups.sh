#!/bin/bash

set -eu

AUTOSCALING_GROUP_NAME="url-shortening-app"

for ITEM in `aws autoscaling describe-auto-scaling-groups --auto-scaling-group-name "${AUTOSCALING_GROUP_NAME}" | grep -i instanceid  | awk '{ print $2}' | cut -d',' -f1 | sed -e 's/"//g'`; do
  aws ec2 describe-instances --instance-ids $ITEM | grep -i PrivateIpAddress | awk '{ print $2 }' | head -1 | cut -d "," -f1
done;
